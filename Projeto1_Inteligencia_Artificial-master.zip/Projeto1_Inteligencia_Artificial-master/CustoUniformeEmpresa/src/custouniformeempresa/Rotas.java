package custouniformeempresa;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.QuadCurve2D;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Rotas extends JPanel {

	private static final long serialVersionUID = 1L;

	private final String PASTA_IMG = "/img_nm_cidades/";

	private JLabel aracaju, barra_dos_coqueiros, sao_crsitovao, n_s_do_socorro, itaporanga, lagarto, sao_domingos,
			campo_do_brito, macambira, itabaiana, laranjeiras, areia_branca, moita_bonita, malhador, ribeiropolis,
			frei_paulo, carira, n_s_aparecida, n_s_da_gloria, m_alegre_de_sergipe, poco_redondo;
	private ArrayList<Dimension> posicoes;

	public Rotas() {
		super();
		posicoes = new ArrayList<>();
	}

	public void init() {
		setLayout(null);

		add(aracaju = carregarLabel("aracaju.png", 600, 450, 240, 100));
		add(barra_dos_coqueiros = carregarLabel("barra_dos_coqueiros.png", 640, 410, 260, 110));
		add(sao_crsitovao = carregarLabel("sao_cristovao.png", 550, 470, 100, 40));
		add(n_s_do_socorro = carregarLabel("n_sra_do_socorro.png", 580, 415, 100, 110));
		add(itaporanga = carregarLabel("itaporanga.png", 500, 460, 100, 43));
		add(lagarto = carregarLabel("lagarto.png", 430, 450, 100, 50));
		add(sao_domingos = carregarLabel("sao_domingos.png", 450, 420, 100, 50));
		add(campo_do_brito = carregarLabel("campo_do_brito.png", 475, 410, 110, 50));
		add(macambira = carregarLabel("macambira.png", 440, 380, 210, 50));
		add(itabaiana = carregarLabel("itabaiana.png", 490, 380, 100, 50));
		add(laranjeiras = carregarLabel("laranjeiras.png", 560, 420, 210, 50));
		add(areia_branca = carregarLabel("areia_branca.png", 520, 420, 100, 55));
		add(moita_bonita = carregarLabel("moita_bonita.png", 520, 370, 110, 40));
		add(malhador = carregarLabel("malhador.png", 550, 390, 110, 40));
		add(ribeiropolis = carregarLabel("ribeiropolis.png", 500, 335, 110, 50));
		add(frei_paulo = carregarLabel("frei_paulo.png", 450, 345, 210, 40));
		add(carira = carregarLabel("carira.png", 415, 290, 210, 50));
		add(n_s_aparecida = carregarLabel("n_sra_aparecida.png", 490, 305, 110, 30));
		add(n_s_da_gloria = carregarLabel("n_sra_da_gloria.png", 485, 250, 210, 50));
		add(m_alegre_de_sergipe = carregarLabel("m_alegre.png", 430, 210, 210, 50));
		add(poco_redondo = carregarLabel("poco_redondo.png", 430, 140, 210, 50));

		add(carregarLabel("TelaInicial.png", 0, 0, 990, 720));
	}

	public void clearPath() {
		aracaju.setVisible(false);
		barra_dos_coqueiros.setVisible(false);
		sao_crsitovao.setVisible(false);
		n_s_do_socorro.setVisible(false);
		itaporanga.setVisible(false);
		lagarto.setVisible(false);
		sao_domingos.setVisible(false);
		campo_do_brito.setVisible(false);
		malhador.setVisible(false);
		itabaiana.setVisible(false);
		areia_branca.setVisible(false);
		laranjeiras.setVisible(false);
		macambira.setVisible(false);
		moita_bonita.setVisible(false);
		ribeiropolis.setVisible(false);
		frei_paulo.setVisible(false);
		carira.setVisible(false);
		n_s_aparecida.setVisible(false);
		n_s_da_gloria.setVisible(false);
		m_alegre_de_sergipe.setVisible(false);
		poco_redondo.setVisible(false);

	}

	public void showPath(Vertice caminho) {

		posicoes.clear();

		while (true) {
			switch (caminho.getPosicao()) {

			case Dados.Aracaju:
				posicoes.add(showLabel(aracaju, 20, 43));
				break;
			case Dados.BarraCoqueiros:
				posicoes.add(showLabel(barra_dos_coqueiros, 6, 55));
				break;
			case Dados.Socorro:
				posicoes.add(showLabel(n_s_do_socorro, 22, 45));
				break;
			case Dados.SaoCristovao:
				posicoes.add(showLabel(sao_crsitovao, 16, 10));
				break;
			case Dados.Itaporanga:
				posicoes.add(showLabel(itaporanga, 20, 15));
				break;
			case Dados.Lagarto:
				posicoes.add(showLabel(lagarto, 30, 22));
				break;
			case Dados.SaoDomingos:
				posicoes.add(showLabel(sao_domingos, 22, 15));
				break;
			case Dados.CampoDoBrito:
				posicoes.add(showLabel(campo_do_brito, 15, 15));
				break;
			case Dados.Macambira:
				posicoes.add(showLabel(macambira, 20, 22));
				break;
			case Dados.Itabaiana:
				posicoes.add(showLabel(itabaiana, 17, 17));
				break;
			case Dados.Laranjeiras:
				posicoes.add(showLabel(laranjeiras, 20,20));
				break;
			case Dados.AreiaBranca:
				posicoes.add(showLabel(areia_branca, 14, 14));
				break;
			case Dados.MoitaBonita:
				posicoes.add(showLabel(moita_bonita, 30, 10));
				break;
			case Dados.Malhador:
				posicoes.add(showLabel(malhador, 5, 15));
				break;
			case Dados.Ribeiropolis:
				posicoes.add(showLabel(ribeiropolis, 18, 18));
				break;
			case Dados.FreiPaulo:
				posicoes.add(showLabel(frei_paulo, 20, 15));
				break;
			case Dados.Carira:
				posicoes.add(showLabel(carira, 20, 15));
				break;
			case Dados.Aparecida:
				posicoes.add(showLabel(n_s_aparecida, 11, 10));
				break;
			case Dados.Gloria:
				posicoes.add(showLabel(n_s_da_gloria, 15, 20));
				break;
			case Dados.MonteAlegre:
				posicoes.add(showLabel(m_alegre_de_sergipe, 20, 15));
				break;
			case Dados.PocoRedondo:
				posicoes.add(showLabel(poco_redondo, 23, 20));
				break;
			}

			if (caminho.getPai() == null)
				break;
			caminho = caminho.getPai();
		}
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);

		if (posicoes.size() > 0) {
			Painter.paint(posicoes, (Graphics2D) g);
		}
	}

	private Dimension showLabel(JLabel label, int x, int y) {
		label.setVisible(true);
		return new Dimension(label.getX() + x, label.getY() + y);
	}

	private JLabel carregarLabel(String imagem, int x, int y, int largura, int altura) {
		JLabel label = new JLabel();
		label.setIcon(new ImageIcon(getClass().getResource(PASTA_IMG + imagem)));
		label.setBounds(x, y, largura, altura);
		return label;
	}

	private static class Painter {
		private static final int raio = 2;

		static void paint(ArrayList<Dimension> posicoes, Graphics2D g2d) {

			g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

			final int size = posicoes.size();

			Dimension cOrigem = null, cDestino = null;

			if (size == 1) {
				circulo(g2d, posicoes.get(size - 1), Color.RED, Color.RED);

			} else if (size > 1) {
				for (int i = size; i > 1; i--) {

					g2d.setStroke(new BasicStroke(4));
					cOrigem = posicoes.get(i - 1);
					cDestino = posicoes.get(i - 2);

					// g2d.setColor(Color.PINK);
					// g2d.drawLine(cOrigem.width, cOrigem.height, cDestino.width, cDestino.height);

					g2d.setColor(Color.DARK_GRAY);
					QuadCurve2D curva = new QuadCurve2D.Float();
					Dimension angulo = angulo(cOrigem, cDestino);
					curva.setCurve(cOrigem.width, cOrigem.height, angulo.width, angulo.height, cDestino.width,
							cDestino.height);
					g2d.draw(curva);

					circulo(g2d, cOrigem, Color.BLUE, Color.WHITE);
				}
				if (cDestino != null) {
					circulo(g2d, cDestino, Color.GREEN, Color.GREEN);
				}
			}
		}

		static void circulo(Graphics2D g2d, Dimension coord, Color borda, Color centro) {

			g2d.setColor(centro);
			int x = coord.width - (raio / 2) - 2;
			int y = coord.height - (raio / 2) - 2;
			g2d.fillOval(x, y, raio * 2, raio * 2);

			g2d.setStroke(new BasicStroke(2));
			g2d.setColor(borda);
			g2d.drawOval(x, y, raio * 2, raio * 2);
		}

		private static Dimension angulo(Dimension origem, Dimension destino) {
			int largura = origem.width == destino.width ? ((origem.height + destino.height) / 2) - origem.width
					: destino.width;
			int altura = origem.height == destino.height ? ((origem.width + destino.width) / 2) - origem.height
					: origem.height;

			// largura += largura * 0.2;
			// altura += altura * 0.2;

			return new Dimension((int) (largura), (int) (altura));
		}
	}
}