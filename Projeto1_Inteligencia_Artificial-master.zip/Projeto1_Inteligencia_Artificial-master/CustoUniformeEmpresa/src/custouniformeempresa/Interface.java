package custouniformeempresa;
import javax.swing.*;
import java.awt.*;

public class Interface extends JFrame {

	protected static JButton btnIniciar = new JButton("Iniciar");
	protected static JComboBox<String> comboOrigem = new JComboBox<>();
	protected static JComboBox<String> comboDestino = new JComboBox<>();
	protected static Rotas rota = new Rotas();

	public Interface() {
		setTitle("Projeto IA 01");
		setSize(994, 735);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		getContentPane().setLayout(null);

		final Font fonte = new Font("Tahoma", Font.PLAIN, 14);
		final String[] cidades = new String[]{
			"Aracaju", "Barra dos Coqueiros", "São Cristóvão", "N Sra do Socorro", "Itaporanga",
			"Lagarto", "São Domingos", "Campo do Brito", "Malhador", "Itabaiana", "Laranjeitas","Areia Branca",
			"Moita Bonita", "Macambira", "Ribeirópolis", "Frei Paulo", "Carira", "N Sra Aparecida", "N Sra da Glória",
			"Monte Alegre de Sergipe", "Poço Redondo"
		};

		comboOrigem = new JComboBox<>(new DefaultComboBoxModel<>(cidades));
		comboOrigem.setFont(fonte);
		comboOrigem.setBounds(840, 367, 150, 24);
		add(comboOrigem);

		comboDestino = new JComboBox<>(new DefaultComboBoxModel<>(cidades));
		comboDestino.setFont(fonte);
		comboDestino.setBounds(840, 408, 150, 24);
		add(comboDestino);

		btnIniciar = new JButton("Iniciar");
		btnIniciar.setFont(fonte);
		btnIniciar.setBounds(855, 465, 124, 30);
		add(btnIniciar);

		rota.setBounds(0, 0, 990, 720);
		rota.init();
		getContentPane().add(rota);

		setVisible(true);
	}
	
	public void clearPaht() {
		rota.clearPath();
	}

	public void showPath(Vertice caminho) {
		rota.clearPath();
		rota.showPath(caminho);	
	}

	public static void main(String[] args) {

		Interface tela = new Interface();

		btnIniciar.addActionListener(e -> {
			System.out.println("Origem: " + comboOrigem.getItemAt(comboOrigem.getSelectedIndex()) + " Destino: " + comboDestino.getItemAt(comboDestino.getSelectedIndex()));
			tela.showPath(new CustoUniformeEmpresa().CustoUniformeEmpresa(comboOrigem.getSelectedIndex(),
					comboDestino.getSelectedIndex()));
			
		});
	}
}
